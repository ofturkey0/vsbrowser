﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace İnternet_Tarayıcısı_Yapma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //Google.com gider ana sayfadır www.google.com/ silip kullanmak istediğiniz arama motorunu yaza bilirsiniz.
            webBrowser1.Navigate("www.google.com/");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            webBrowser1.Navigate(textBox1.Text);


            //Özel Komutlar.(İstediğiniz gibi değiştire bilirsiniz..)


            //Örnek Komutar eğer .yardım yerine başka bir şey yazıp altakini değiştiriseniz kendi komutlarınızı yapmış olursunuz.


            if (textBox1.Text == ".yardım")
            {
                //Alta bulunan yere "" içindeki yani istediğiniz yeri yazarsınız
                webBrowser1.Navigate("https://ofturkey0.github.io/vsbrowser/");
            }
            //O an ki site url'sini yansıtır. (basit bir işlemdir eğer sayda içinde başka bir yere atlarsanız ordaki url almaz.)
            label1.Text = textBox1.Text;

            


        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
